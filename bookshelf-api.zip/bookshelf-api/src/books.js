// src/books.js
const books = [];

module.exports = books;
